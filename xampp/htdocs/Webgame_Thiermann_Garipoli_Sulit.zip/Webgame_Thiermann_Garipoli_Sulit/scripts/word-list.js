const wordList = [
    {
        word: "ahzos",
    },
];